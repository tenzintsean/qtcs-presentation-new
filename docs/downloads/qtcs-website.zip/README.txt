QTCS Website - Deployment Instructions
======================================

This package contains the complete QTCS website ready for deployment
to any web hosting service.

CONTENTS:
---------
- index.html          Home page
- about/              About QTCS page
- contact/            Contact page with form
- products/           Vehicle product pages
- _astro/             CSS and JavaScript assets

DEPLOYMENT STEPS:
-----------------
1. Extract the contents of this ZIP file
2. Upload ALL files and folders to your web server
3. Ensure index.html is in the root directory
4. That's it! The website is ready to use.

REQUIREMENTS:
-------------
- Any standard web server (Apache, Nginx, IIS, etc.)
- OR static hosting services:
  - Netlify (drag & drop deployment)
  - Vercel
  - AWS S3 + CloudFront
  - GitHub Pages
  - Any shared hosting with FTP access

NO server-side configuration required - this is a static website.

LIGHTHOUSE SCORES:
------------------
Performance:    99/100
Accessibility:  93/100
Best Practices: 100/100
SEO:           100/100

SUPPORT:
--------
For technical support, please contact:
- Email: info@qtcs.in
- Website: https://qtcs.in

(c) 2025 QTCS - Quick Turn Consultancy Solutions
